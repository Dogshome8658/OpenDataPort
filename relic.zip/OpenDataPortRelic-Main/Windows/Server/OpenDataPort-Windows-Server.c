﻿#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#define _GNU_SOURCE
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <winsock2.h>
#include <windows.h>
#include <conio.h>
#include<time.h>
//#include"SocketConsole.h"
//#include"ConfigHandle.h"
//#include "C:\OpenSSL\openssl-3.0.14\include\openssl\evp.h"
#pragma comment (lib, "Ws2_32.lib")
//#pragma comment (lib,"licrypto.lib")
//#pragma comment (lib,"crypt32.lib")
// #pragma comment (lib, "Mswsock.lib")

#define DEFAULT_BUFLEN 1024
#define DEFAULT_PORT 27015
#define ONLINELIMIT 50
#define TRANSPORTLIMIT 10000
#define STREAM FILE*
#define PageDesity 64//For future select() devlopment

const char Version_Comfirm[50] = "ODP_Offical_B.0.1,VERSION_COMFIRM";
static HANDLE MainThreadHandle = NULL;
FILE* LogFile = NULL;
//#define NOT_ACTIVATE NULL

#define IDLE 0
#define RESERVED -1
#define ACTIVATED 1

#define HANDSHAKEFAILED -1

struct _ConfigType {
	char LanIP[16] = "192.168.0.193";
	unsigned short int LanPort = 27150;
	char ServerName[50]="An OpenDataPort\0";
	char LoginPWD[50] = "ODP";
	BOOL ReqirePWD = FALSE;
	unsigned int PageLimit = 100;
}ConfigInfo;

struct _RoleInfo {
	char RoleName[25]="Defalte\0";
	BOOL AbleToKick = FALSE;
	BOOL AbleToBan = FALSE;
	BOOL ShowColour = TRUE;
	COLORREF RoleColour = RGB(255, 255, 255);
	BOOL AbleToMute = FALSE;
	BOOL AbleToFocusEditName = FALSE;
	BOOL AbleToCreateChannle = TRUE;
	BOOL AbleToDeleteChannle = FALSE;
	BOOL AbleToEditChannleConfig = FALSE;
	BOOL AbleToCreateSort = TRUE;
	BOOL AbleToDeleteSort = FALSE;
	BOOL AbleToEditSortConfig = FALSE;
	BOOL AbleMoveChannleToSort = FALSE;
	BOOL AbleToAddChannleDirectlyToSort = TRUE;
	BOOL IsAdmin = FALSE;
	BOOL IsAdminInOwnedSort = TRUE;
};

struct _UserData{
	char UserAcc[100];
	char UserPWD[100];
	_RoleInfo RoleData[6];
	char UserName[25]="Unintized\0";
};

struct GobalTHDIndexT {
	unsigned long int PageIndex;
	unsigned char THDIndex;
};

struct _ThreadDeployInfo{
	WSADATA* BasicInfo;
	SOCKET ConnectionSocket;
	HANDLE THDHandle;
	int State = IDLE;
	GobalTHDIndexT GobalTHDIndex;
	sockaddr RemoteAddress;
	_UserData ConnectionUser;
};

struct _THDPage{
	unsigned long int PageIndex = 0;
	unsigned char ActvatedTHD = 0;
	_THDPage* Prevous;
	_ThreadDeployInfo THD[PageDesity];
	_THDPage* Next;
	BOOL IsConnectToFirstPage=TRUE;
}FirstPage;

WSADATA wsaData;
unsigned long int CurrentOnline = 0;
typedef _THDPage THDPage;
typedef _ThreadDeployInfo ThreadDeployInfo;
typedef _UserData UserData;
typedef _RoleInfo RoleInfo;
typedef wchar_t UnicodeChar;
typedef struct _ConfigType ConfigType;

THDPage* AllocNewTHDPage(THDPage* PrevousPage) {
	int i = 0;
	if ((PrevousPage->IsConnectToFirstPage) == TRUE||(PrevousPage->PageIndex)==0) {
		THDPage* TEMP = (THDPage *)malloc(sizeof(THDPage));
		if (TEMP == NULL) {
			return NULL;
		}else {
			PrevousPage->Next = TEMP;
			TEMP->Prevous = PrevousPage;
			TEMP->Next = NULL;
			TEMP->IsConnectToFirstPage = TRUE;
			TEMP->PageIndex = (PrevousPage->PageIndex) + 1;
			do{
				TEMP->THD[i].BasicInfo = &wsaData;
				TEMP->THD[i].ConnectionSocket = NULL;
				TEMP->THD[i].GobalTHDIndex.PageIndex = TEMP->PageIndex;
				TEMP->THD[i].RemoteAddress.sa_family=NULL;
				TEMP->THD[i].THDHandle = NULL;
				TEMP->THD[i].State = IDLE;
				TEMP->THD[i].GobalTHDIndex.THDIndex = i;
				i++;
			} while (i != 100||i>=100);
			return TEMP;
		}
	}
	return NULL;
}

BOOL FreeTHDPage(THDPage* Target) {
	if (Target->PageIndex == 0) {
		return FALSE;
	}
	if ((Target->Next) == NULL||(Target->ActvatedTHD)!=0) {
		return FALSE;
	}else{
		Target->Prevous->Next = NULL;
		free(Target);
		return TRUE;
	}
}

ThreadDeployInfo* AllocThreadDeployInfo(void){
	char i = 0;
	THDPage* TEMP = &FirstPage;
	if ((FirstPage.ActvatedTHD) < 100) {
		while (1) {
			if (FirstPage.THD[i].State == IDLE) {
			return &FirstPage.THD[i];
			}
			if (i == 99){
				break;
			}
			i++;
		}
		//Serech IDLE THDI on first page
	}
	TEMP = TEMP->Next;//Next page
	if ((TEMP->ActvatedTHD) < 100) {//Check if full
		while (1) {
			if (TEMP->THD[i].State == IDLE) {
				return &TEMP->THD[i];//If found then return
			}
			if (i == 99) {
				TEMP=TEMP->Next;//Next page
				i = 0;
			}
			if (TEMP == NULL) {
				return NULL;//Not alivaerable
			}
			i++;
			}
		}
	return NULL;
} 

BOOL FreeThreadDeployInfo(ThreadDeployInfo* Target) {
	Target->ConnectionSocket = NULL;
	Target->BasicInfo = &wsaData;
	Target->ConnectionSocket = NULL;
	Target->RemoteAddress.sa_family = NULL;
	Target->THDHandle = NULL;
	Target->State = IDLE;
	return TRUE;
}

void lprintf(const char* MSG, ...){
	struct timespec ts;
	timespec_get(&ts, TIME_UTC);
	char time_buf[100];
	size_t rc = strftime(time_buf, sizeof time_buf, "%D %T", gmtime(&ts.tv_sec));
	snprintf(time_buf + rc, sizeof time_buf - rc, ".%06ld UTC", ts.tv_nsec / 1000); //Get the time
	va_list args1;
	va_start(args1, MSG);
	va_list args2;
	va_copy(args2, args1);
	int temp = vsnprintf(NULL, 0, MSG, args1);
	char* buf = (char*)malloc(1 + temp);
	//char buf[1 + vsnprintf(NULL, 0, fmt, args1)];
	va_end(args1);
	vsnprintf(buf,temp+1, MSG, args2);
	va_end(args2);
	if (GetCurrentThread() == MainThreadHandle) {
		printf("[Main Thread][%s]: %s\n", time_buf, buf);
	}else {
		printf("[Thread %x][%s]: %s\n", GetCurrentThreadId(), time_buf, buf);
	}
}

void FancyReturn(int ReturnValue){
	exit();
}

DWORD WINAPI UserConnection(void* _DeployInfo) {
	((ThreadDeployInfo*)_DeployInfo)->State = ACTIVATED;
	ThreadDeployInfo* DeployInfo = (ThreadDeployInfo*)_DeployInfo;
	SOCKET* ResponsbleSocket = &(DeployInfo->ConnectionSocket);
	char Handshake[16] = "QB000001ABCDEF\0";
	int SocketStaute = 0;
	SocketStaute=send(*ResponsbleSocket,&Handshake[0],16,NULL );
	if (SocketStaute == SOCKET_ERROR) {
		lprintf("Failed to shake!WSAGetLastError:%d\(send\(\)\)\n",WSAGetLastError());
		WSACleanup();
		return HANDSHAKEFAILED;
	}
	char
	SocketStaute=recv((ResponsbleSocket),&Handshake[0],16,NULL);
	if(SocketStaute==SOCKET_ERROR||SocketStaute==0){
		lprintf("Failed to shake!WSAGetLastError:%d\(recv\(\)\)\n",WSAGetLastError());
	}
	return 0;
}


int main(int Number) {
	//openssl_add_all_algorithms();
	MainThreadHandle= GetCurrentThread();
	LogFile=("LatestLog.txt","w");
	THDPage* CurrentNewestPage = &FirstPage;
	int IdleTHD = -1;
	int iResult;
	printf("\aReDataPort Beta0.1 by Dogshome\nServer B-0.1\n");
	printf("[Main Thread]Start to initialize Winsock2.2\n");
	// Initialize Winsock by see is iResult is 0 or not 
	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0) {
		printf("[Main Thread]WSAStartup failed: %d\n", iResult);
		printf("[Main Thread]This may cause by the running environment isn't able to use Winsock2.2!\n[Main Thread]Also the program was only test on Win11 before!\n");
		WSACleanup();
		return 1;
	}
	printf("[Main Thread]Initialized Winsock2.2\n");
	char Count = 0;
	//Info Setup
	/*do {
		UserInfo[Count].THDNum = Count;
		UserInfo[Count].BasicInfo = &wsaData;
		UserInfo[Count].THDNumPTR = &UserInfo[Count].THDNum;
		UserInfo[Count].Sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		if (UserInfo[Count].Sock == INVALID_SOCKET) {
			WSACleanup();
			return 5;
		}
		Count++;
	} while (UserInfo[ONLINELIMIT - 1].THDNum != ONLINELIMIT - 1); //Setup THREAD INFO*/
	Count = 0;
	char Shutdown = 0;
	SOCKET ListenSocket;
	{
	SOCKETFAILEDRETRY:
		ListenSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		Count++;
		printf("[Main Thread]Tried %d time(s) to socket(),the program will exit after 10 tries\n\a", Count);
		if (ListenSocket == INVALID_SOCKET) {
			printf("[Main Thread]socket() Failed!\n");
			if (Count == 10) {
				printf("[Main Thread]Tried 10 times!\n[Main Thread]The server will be returned soon!\n");
				return 2;
			}
			Sleep(20);
			goto SOCKETFAILEDRETRY;
		}
		printf("[Main Thread]Succeeded to socket()!\n");
	}//socket()
	sockaddr_in SerAddr_in;
	SerAddr_in.sin_family = AF_INET;
	SerAddr_in.sin_addr.s_addr = inet_addr(ConfigInfo.LanIP);
	SerAddr_in.sin_port = htons(ConfigInfo.LanPort);
	Count = 0;
	char ReturnVaule = 0;
	Sleep(200);
	{
		ReturnVaule = bind(ListenSocket, (SOCKADDR*)&SerAddr_in, sizeof(SerAddr_in));
		if (ReturnVaule != 0) {
			printf("[Main Thread]bind() Failed,other program may bind to %d\n", ConfigInfo.LanPort);
			WSACleanup();
			return 3;
		}
		printf("[Main Thread]Binded!\n[Main Thread]IP:%s:%d\n", ConfigInfo.LanIP, ConfigInfo.LanPort);
	}
	ReturnVaule = 100;
	{
		ReturnVaule = listen(ListenSocket, ONLINELIMIT);
		if (ReturnVaule != 0) {
			printf("[Main Thread]Failed to listen!\n");
			WSACleanup();
			return 4;
		}
		Sleep(100);
		printf("[Main Thread]Succeeded to listen!\n");
		Sleep(100);
	}//listen
	Count = 0;
	IdleTHD = -1;
	ThreadDeployInfo* SimpleAllocPointer = NULL;
	char FailedToCounter = 0;
	do {
		FailedToCounter = 0;
		/* {
			IdleTHD = -1;
			Count = 0;
			do {
				if (UserInfo[Count].State == 0) {
					IdleTHD = Count;
					printf("[Main Thread]Selected a THD!\n\a");
				}
				if (UserInfo[Count].State != 0) {
					Count++;
				}
				if (Count >= ONLINELIMIT) {
					Count = 0;
				}
			} while (IdleTHD != Count);
		}//Choose Idle THD*/
		IDKPeanut:
		ThreadDeployInfo* NewConnectionAllocPointer = AllocThreadDeployInfo();
		if (NewConnectionAllocPointer == NULL) {
			printf("[Main Thread]Failed to allocate a DeployInfo!\n[Main Thread]Going to allocate a new page!\n");
			CurrentNewestPage=AllocNewTHDPage(CurrentNewestPage);
			if (CurrentNewestPage == NULL) {
				printf("[Main Thread]Unable to allocate new page!\n[Main Thread]May used all of memory or reached online limit!\n");
				Sleep(5000);
				FailedToCounter++;
				goto IDKPeanut;
			}
		}
		FailedToCounter = 0;
		retryaccept:
		NewConnectionAllocPointer->State = RESERVED;
		NewConnectionAllocPointer->ConnectionSocket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
		NewConnectionAllocPointer->ConnectionSocket = accept(ListenSocket, &NewConnectionAllocPointer->RemoteAddress, NULL);
		if (NewConnectionAllocPointer->ConnectionSocket == INVALID_SOCKET) {
			printf("[Main Thread]Failed to accept a new connection!\n");
			FailedToCounter++;
			if (FailedToCounter == 100) {
				printf("[Main Thread]Failed to accept new connections for 25 times!\n");
				return 69;
			}
			goto retryaccept;
		}
		NewConnectionAllocPointer->THDHandle = CreateThread(NULL, 0, UserConnection, (void*)NewConnectionAllocPointer, 0, NULL);
		NewConnectionAllocPointer->State = ACTIVATED;
	} while (1);
	WSACleanup();
	printf("[Main Thread]Press To Shutdown!\n");
	int ADWDFE = _getch();//Press To Continu
	return 0;
}

//I just aimed to shit a release in a beta