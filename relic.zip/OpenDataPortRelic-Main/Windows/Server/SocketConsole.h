#include <stdio.h>
#include <stdlib.h>
#include <winsock2.h>
#include <windows.h>
#include <conio.h>

struct _Console{
	SOCKET ConsoleSocket = INVALID_SOCKET;
	wchar_t Buffer[10000] = L"\0";
};